const { pool } = require("./pool");

async function seed() {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    await client.query(
      `INSERT INTO apps(id, name, slug, status, description)
       VALUES
         ('app-study-12', 'Hoc Tap Lop 12', 'hoc-tap-lop-12', 'active', 'Nen tang luyen de thi THPT va AI tro giang cho hoc sinh lop 12.'),
         ('app-ai-writing', 'AI Writing Coach', 'ai-writing-coach', 'coming_soon', 'Cong cu viet va sua bai theo ngu canh hoc tap va cong viec.')
       ON CONFLICT (id) DO UPDATE SET
         name = EXCLUDED.name,
         slug = EXCLUDED.slug,
         status = EXCLUDED.status,
         description = EXCLUDED.description`
    );

    await client.query(
      `INSERT INTO products(id, app_id, name, cycle, price, currency, credits, active)
       VALUES
         ('prod-study-month', 'app-study-12', 'Goi Thang', 'monthly', 99000, 'VND', 120, TRUE),
         ('prod-study-year', 'app-study-12', 'Goi Nam', 'yearly', 890000, 'VND', 1800, TRUE),
         ('prod-study-topup', 'app-study-12', 'Top-up 300 Credit', 'one_time', 149000, 'VND', 300, TRUE)
       ON CONFLICT (id) DO UPDATE SET
         app_id = EXCLUDED.app_id,
         name = EXCLUDED.name,
         cycle = EXCLUDED.cycle,
         price = EXCLUDED.price,
         currency = EXCLUDED.currency,
         credits = EXCLUDED.credits,
         active = EXCLUDED.active`
    );

    await client.query(
      `INSERT INTO customers(id, email, full_name)
       VALUES ('cus-demo', 'demo@user.local', 'Demo Customer')
       ON CONFLICT (id) DO UPDATE SET
         email = EXCLUDED.email,
         full_name = EXCLUDED.full_name`
    );

    await client.query(
      `INSERT INTO credit_wallets(customer_id, app_id, balance)
       VALUES ('cus-demo', 'app-study-12', 0)
       ON CONFLICT (customer_id, app_id) DO NOTHING`
    );

    await client.query("COMMIT");
    console.log("Seed completed.");
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Seed failed:", error.message);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
